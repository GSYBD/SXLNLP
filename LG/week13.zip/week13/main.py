# -*- coding: utf-8 -*-

import torch
import os
import random
import numpy as np
import logging
from config import Config
from model import TorchModel, choose_optimizer
from evaluate import Evaluator
from loader import load_data
from peft import get_peft_model, LoraConfig, TaskType, PromptEncoderConfig, PromptTuningConfig, PrefixTuningConfig

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

"""
模型训练主程序
"""


# GPU 检测并迁移模型
def move_to_device(model):
    if torch.cuda.is_available():
        logger.info("GPU detected. Moving model to GPU...")
        return model.cuda()
    else:
        logger.info("No GPU available. Using CPU...")
        return model


# 选择微调策略
def select_peft_strategy(config, model):
    tuning_tactics = config["tuning_tactics"]

    if tuning_tactics == "lora_tuning":
        peft_config = LoraConfig(
            r=8,
            lora_alpha=32,
            lora_dropout=0.1,
            target_modules=["query", "key", "value"]
        )
    elif tuning_tactics == "p_tuning":
        peft_config = PromptEncoderConfig(task_type="SEQ_CLS", num_virtual_tokens=10)
    elif tuning_tactics == "prompt_tuning":
        peft_config = PromptTuningConfig(task_type="SEQ_CLS", num_virtual_tokens=10)
    elif tuning_tactics == "prefix_tuning":
        peft_config = PrefixTuningConfig(task_type="SEQ_CLS", num_virtual_tokens=10)
    else:
        raise ValueError("Invalid tuning tactic specified!")

    model = get_peft_model(model, peft_config)

    if tuning_tactics == "lora_tuning":
        for param in model.get_submodule("model").get_submodule("classify").parameters():
            param.requires_grad = True

    return model


# 仅存储当前微调的参数（模型会更小）
def save_tunable_parameters(model, path):
    saved_params = {
        k: v.to("cpu")
        for k, v in model.named_parameters()
        if v.requires_grad
    }
    torch.save(saved_params, path)
    logger.info(f"Model parameters saved to {path}")


def main(config):
    # 创建保存模型的目录
    os.makedirs(config["model_path"], exist_ok=True)

    # 加载训练数据
    train_data = load_data(config["train_data_path"], config)

    # 加载模型
    model = TorchModel(config)

    # 选择微调策略
    model = select_peft_strategy(config, model)

    # 将模型迁移至GPU（如可用）
    model = move_to_device(model)

    # 加载优化器
    optimizer = choose_optimizer(config, model)

    # 加载评估器
    evaluator = Evaluator(config, model, logger)

    # 训练过程
    for epoch in range(1, config["epoch"] + 1):
        model.train()
        logger.info(f"Epoch {epoch} begin")
        train_loss = []

        for index, batch_data in enumerate(train_data):
            optimizer.zero_grad()

            # 批量迁移到GPU（如可用）
            batch_data = [d.cuda() for d in batch_data] if torch.cuda.is_available() else batch_data

            input_id, labels = batch_data
            loss = model(input_id, labels)
            loss.backward()
            optimizer.step()

            train_loss.append(loss.item())

            # 打印每个epoch的中间损失值
            if index % (len(train_data) // 2) == 0:
                logger.info(f"Batch {index}, loss: {loss.item()}")

        avg_loss = np.mean(train_loss)
        logger.info(f"Epoch {epoch} average loss: {avg_loss:.6f}")

        # 评估模型
        evaluator.eval(epoch)

        # 保存模型参数
        model_path = os.path.join(config["model_path"], f"epoch_{epoch}.pth")
        save_tunable_parameters(model, model_path)

    return model, train_data


if __name__ == "__main__":
    model, train_data = main(Config)
