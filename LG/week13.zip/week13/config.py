# -*- coding: utf-8 -*-

"""
配置参数信息
"""

Config = {
    "model_path": "model_output",
    "schema_path": r"schema.json",
    "train_data_path": r"train.txt",
    "valid_data_path": r"test.txt",
    "vocab_path": r"chars.txt",
    "max_length": 100,
    "hidden_size": 256,
    "num_layers": 2,
    "epoch": 8,
    "batch_size": 16,
    "optimizer": "adam",
    "learning_rate": 1e-3,
    "use_crf": False,
    "class_num": 9,
    "bert_path": r"E:\BaDou\bert-base-chinese",
    "tuning_tactics": "lora_tuning"
}